/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3105;

/**
 *
 * @author badnoby
 */
public class AsistenPraktikum_3105 extends Mahasiswa_3105 {
    String mkAsisten_3105;
    int jmlPertemuan_3105;
    
    public double totalPendapatan_3105(){
        return(jmlPertemuan_3105 * 50000);
    }
    public void tampilDataAsistenPraktikum_3105() {
        super.tampilDataMhs_3105();
        System.out.println(" Mata Kuliah    : " + mkAsisten_3105);
        System.out.println(" Jumlah Pertemuan   : " + jmlPertemuan_3105);
        System.out.println(" Total Pendapatan : " + totalPendapatan_3105());
        
        
    }
}
