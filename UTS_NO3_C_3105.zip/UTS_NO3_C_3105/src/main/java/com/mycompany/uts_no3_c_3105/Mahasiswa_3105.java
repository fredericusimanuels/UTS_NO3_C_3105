/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3105;

/**
 *
 * @author badnoby
 */
import java.io.BufferedReader;
public class Mahasiswa_3105 {
    String nim_3105, nama_3105, jurusan_3105;
    int ipk_3105;
    
    public void tampilDataMhs_3105() {
        System.out.println(" NIM    : " + nim_3105);
        System.out.println("Nama    " + nama_3105);
        System.out.println("Jurusan    : " + jurusan_3105);
        System.out.println("IPK : " + ipk_3105);
    }
}
