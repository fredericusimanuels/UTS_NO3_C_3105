/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3105;

/**
 *
 * @author badnoby
 */
public class StudentStaff_3105 extends Mahasiswa_3105 {
    int jamKerja_3105;
    String unitKerja_3105;
    
    public double totalPendapatan_3105(){
        return (jamKerja_3105 * 30000);
    }
    public void tampilDataStudentStaff_3105(){
        super.tampilDataMhs_3105();
        System.out.println(" Unit Kerja : " + unitKerja_3105);
        System.out.println(" Jam Kerja : " +jamKerja_3105);
        System.out.println(" Total Pendapatan Student Staff : " +totalPendapatan_3105());
    }
}
